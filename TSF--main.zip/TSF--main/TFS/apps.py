from django.apps import AppConfig


class TfsConfig(AppConfig):
    name = 'TFS'
